/*
OBJECTIVES COMPLETED 
CREATE VIEW 
DISPLAY VIEW
UPDATE 
ALTER
*/

CREATE DATABASE view_1;
USE view_1;
CREATE TABLE a3_info(roll_no INT NOT NULL, name VARCHAR(30),cs_lang VARCHAR(30),PRIMARY KEY (roll_no));
INSERT INTO a3_info VALUES(37,'STUD_6','SQL');
INSERT INTO a3_info VALUES(38,'STUD_7','PYTHON')
INSERT INTO a3_info VALUES(39,'STUD_8','JAVA');
INSERT INTO a3_info VALUES(40,'STUD_9','C++');
INSERT INTO a3_info VALUES(41,'STUD_10','REACT');
SELECT * FROM a3_info;
/*
+---------+-----------+---------+
| roll_no | name      | cs_lang |
+---------+-----------+---------+
|      37 | STUD_6 | SQL     |
|      38 | STUD_7   | PYTHON  |
|      39 | STUD_8    | JAVA    |
|      40 | STUD_9    | C++     |
|      41 | STUD_10     | REACT   |
+---------+-----------+---------+
*/
CREATE VIEW temp AS SELECT roll_no , cs_lang FROM a3_info;
SHOW TABLES;
/*
+------------------+
| Tables_in_view_1 |
+------------------+
| a3_info          |
| temp             |
+------------------+
*/
SELECT * FROM temp;
/*
+---------+---------+
| roll_no | cs_lang |
+---------+---------+
|      37 | SQL     |
|      38 | PYTHON  |
|      39 | JAVA    |
|      40 | C++     |
|      41 | REACT   |
+---------+---------+
*/
UPDATE temp SET cs_lang='ANGULAR' WHERE roll_no=41;
/*
+---------+---------+
| roll_no | cs_lang |
+---------+---------+
|      37 | SQL     |
|      38 | PYTHON  |
|      39 | JAVA    |
|      40 | C++     |
|      41 | ANGULAR |
+---------+---------+
*/
ALTER VIEW temp AS SELECT name FROM a3_info;

/*
+-----------+
| name      |
+-----------+
| STUD_6 |
| STUD_7   |
| STUD_8    |
| STUD_9    |
| STUD_10     |
+-----------+
*/


